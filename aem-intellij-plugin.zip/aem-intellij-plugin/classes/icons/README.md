Font used for icons (32px)

- family: PT Sans
- size: 20px
- weight: bold
